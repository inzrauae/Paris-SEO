# Quick Reference Guide - Google Maps Location Picker

## 🚀 What's New

### Feature 1: Location Picker with Google Maps
**Where:** `book-ride.php` - "Pickup Location" & "Drop Off Location" fields

✨ Click the **location icon** → Interactive map opens → Select location visually

### Feature 2: Smart Return Fields
**Where:** `thankyou.html` - Booking confirmation page

🎯 Return fields automatically **hide** when user selects "One way"

---

## 📋 Installation Steps

### Step 1: Replace Files
Copy these files to your server:
- `book-ride.php` → Replace existing file
- `thankyou.html` → Replace existing file

### Step 2: Update Google Maps API Key
**In book-ride.php, find line ~1207:**
```javascript
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_GOOGLE_MAPS_API_KEY&libraries=places&callback=initGoogleMapsAutocomplete" async defer></script>
```

**Replace `YOUR_GOOGLE_MAPS_API_KEY` with your actual key**

### Step 3: Test
1. Go to booking page
2. Click location icon next to "Pickup Location"
3. Map should open - if not, check API key
4. Complete a booking with "One way" type
5. Check thank you page - return fields should be hidden

---

## 🎨 Visual Guide

### Location Picker Interface

```
┌─────────────────────────────────────────┐
│  Pickup Location: Address with City  🗺️  │  ← Click icon
└─────────────────────────────────────────┘
         (Input field)


Click icon ↓

┌─────────────────────────────────────────────────────────────────┐
│ ✕  Select Pickup Location                                       │
├─────────────────────────────────────────────────────────────────┤
│ [Paris] [Disneyland] [CDG] [Orly] [Beauvais]  ← Quick buttons   │
│ ┌─ Search location... ─────────────────────────────────────────┐│
│ │ (Type and press Enter)                                        ││
│ ├─────────────────────────────────────────────────────────────┤│
│ │                                                               ││
│ │              🗺️  INTERACTIVE MAP                             ││
│ │         (Click to select location)                           ││
│ │          (Drag marker to adjust)                             ││
│ │                                                               ││
│ │                      📍 (Marker)                             ││
│ │                                                               ││
│ └─────────────────────────────────────────────────────────────┘│
│ Selected: 48 Rue de Rivoli, 75004 Paris                        │
├─────────────────────────────────────────────────────────────────┤
│                           [Cancel]  [Select Location] ✓         │
└─────────────────────────────────────────────────────────────────┘
```

### Thank You Page - Return Fields

**BEFORE (All fields shown):**
```
Pickup Address          | Dropoff Address
Date                   | Time
Return Pickup Address  | Return Dropoff Address   ← Hidden when "One way"
Return Date           | Return Time               ← Hidden when "One way"
Pickup Type: Return
```

**AFTER (One way selected):**
```
Pickup Address         | Dropoff Address
Date                  | Time
Pickup Type: One way
```

---

## 🔧 Key Features

| Feature | Description | Where |
|---------|-------------|-------|
| **Location Icon** | Orange map icon next to address fields | book-ride.php |
| **Interactive Map** | Click anywhere to place marker | Modal window |
| **Quick Buttons** | 5 predefined Paris locations | Modal top |
| **Search Bar** | Type location name + Enter | Modal top |
| **Draggable Marker** | Drag pin to adjust location | Modal map |
| **Address Display** | Shows selected address before confirming | Modal bottom |
| **Auto-hide Returns** | Hide return fields for "One way" | thankyou.html |

---

## 📱 Mobile Experience

✅ Fully responsive design
✅ Touch-friendly buttons & icons
✅ Optimized map for small screens
✅ Works on all major browsers

---

## 🎯 User Experience Flow

### Booking Process

```
User enters booking page
          ↓
Sees location fields with map icons
          ↓
Clicks map icon (pickup location)
          ↓
Map modal opens → User selects location
          ↓
Location automatically fills input field
          ↓
Repeats for drop-off location
          ↓
Selects "One way" or "Return"
          ↓
Submits form
          ↓
Redirected to thank you page
          ↓
Return fields hidden/shown based on type
```

---

## ⚙️ Technical Stack

```
Frontend:
├── HTML5 (Location inputs & modal)
├── CSS3 (Styling & animations)
├── JavaScript (Vanilla - no jQuery required)
└── Bootstrap 5 (Form styling)

Backend:
├── Google Maps API
│   ├── Maps Library (map display)
│   ├── Geocoding API (address lookup)
│   ├── Places API (autocomplete)
│   └── Directions API (optional)
└── PHP (Form processing)
```

---

## 🔐 Security Notes

✅ No sensitive data exposed
✅ API key can be restricted to domains
✅ All geocoding happens on client-side
✅ No user data stored in modal

**Recommendation:** Set API key restrictions in Google Cloud Console
- Application restrictions: HTTP referrers
- API restrictions: Maps, Geocoding, Places

---

## 🐛 Common Issues & Solutions

### ❌ Map Not Showing
**Solution:** 
1. Check Google Maps API key is valid
2. Verify Maps & Places libraries are enabled
3. Open browser console (F12) for errors

### ❌ Location Not Updating
**Solution:**
1. Make sure to click "Select Location" button
2. Check that address appears in modal before confirming
3. Verify form field ID matches code

### ❌ Return Fields Still Visible
**Solution:**
1. Check URL has `pickuptype=One%20way` parameter
2. Verify pickup type is exactly "One way" (not "Oneway")
3. Hard refresh page (Ctrl+Shift+R or Cmd+Shift+R)

---

## 📊 Customization Options

### Change Colors
**File:** book-ride.php, CSS section (~line 115)
```css
background: linear-gradient(135deg, #FF6B35 0%, #FF8555 100%);
                                    ↑           ↑
                            Change these hex codes
```

### Add/Remove Quick Locations
**File:** book-ride.php, HTML section (~line 1202)
```html
<button class="location-btn" data-location="YOUR_LOCATION">Label</button>
```

### Change Map Default Center
**File:** book-ride.php, JavaScript section (~line 1225)
```javascript
const defaultCenter = { lat: 48.8566, lng: 2.3522 };
                             ↑              ↑
                    Change these coordinates
```

---

## 📈 Performance Tips

⚡ Maps load asynchronously - no page delay
🎯 Geocoding cached - repeated searches are instant
📦 Lightweight implementation - minimal code bloat
🔄 No page refresh needed for location selection

---

## 🌍 Supported Browsers

| Browser | Desktop | Mobile |
|---------|---------|--------|
| Chrome | ✅ | ✅ |
| Firefox | ✅ | ✅ |
| Safari | ✅ | ✅ |
| Edge | ✅ | ✅ |
| IE 11 | ❌ | - |

---

## 📞 Support Checklist

Before contacting support, verify:
- [ ] API key is valid and contains ALL required libraries
- [ ] Files replaced correctly (book-ride.php, thankyou.html)
- [ ] No console errors (F12 → Console tab)
- [ ] Browser is updated to latest version
- [ ] Cache cleared (Ctrl+Shift+Delete or Cmd+Shift+Delete)

---

## 📝 Files Included

```
├── book-ride.php              ← Updated with map picker
├── thankyou.html              ← Updated with conditional fields
├── IMPLEMENTATION_GUIDE.md    ← Detailed documentation
└── QUICK_REFERENCE.md         ← This file
```

---

## ✅ Verification Checklist

After installation, verify:

```
Location Picker (book-ride.php):
- [ ] Location icons visible next to address fields
- [ ] Icons are orange colored
- [ ] Clicking icon opens modal
- [ ] Map displays and is interactive
- [ ] Quick location buttons work
- [ ] Search bar accepts input
- [ ] Marker appears and can be dragged
- [ ] Selected address displays
- [ ] "Select Location" button fills input field
- [ ] Modal closes properly

Return Fields (thankyou.html):
- [ ] Submit booking with "One way"
- [ ] Return page loads
- [ ] Return fields NOT visible
- [ ] Submit booking with "Return"
- [ ] Return page loads
- [ ] Return fields ARE visible

Mobile:
- [ ] All features work on phone
- [ ] All features work on tablet
- [ ] Buttons are easily tappable
```

---

## 🔗 API Requirements

### Google Maps API Needs These APIs Enabled:
1. **Maps JavaScript API** - Map display
2. **Geocoding API** - Address lookup
3. **Places API** - Address autocomplete

### How to Enable:
1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Select your project
3. Go to "APIs & Services" > "Library"
4. Search for and enable each API above
5. Create an API key (if not done)
6. Set restrictions (domain & API)

---

## 💡 Pro Tips

1. **Add More Quick Locations:** Edit the predefined button list to match your common routes

2. **Customize Colors:** Match your brand colors by updating CSS gradients

3. **Change Map Zoom:** Adjust the zoom level (~line 1224) for different default views

4. **Add Address Validation:** Consider adding postal code validation for specific regions

5. **Integrate with Analytics:** Track which locations users select most

---

## 🚀 Next Steps

1. **Install files** using steps above
2. **Update API key** with your actual key
3. **Test thoroughly** using checklist provided
4. **Customize** colors/locations to match your brand
5. **Deploy** to production

---

**Implementation Date:** May 8, 2026  
**Status:** ✅ Ready for Production  
**Support Level:** Full Documentation Included

