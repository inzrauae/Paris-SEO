-- SQL to recreate `rates` table and populate it with the uploaded price chart
-- Import in phpMyAdmin (select the `parisfasttransfer` database and use Import)

USE parisfasttransfer;

CREATE TABLE IF NOT EXISTS rates (
  id INT AUTO_INCREMENT PRIMARY KEY,
  from_loc VARCHAR(50) NOT NULL,
  to_loc VARCHAR(50) NOT NULL,
  label VARCHAR(255) NOT NULL,
  active TINYINT(1) DEFAULT 1,
  prices TEXT,
  created DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- CDG TO Disneyland
INSERT INTO rates (from_loc, to_loc, label, active, prices) VALUES
('CDG','DISNEYLAND','CDG TO Disneyland',1,'{"3":80,"4":85,"5":90,"6":90,"7":90,"8":105,"9":170,"10":170,"11":170,"12":180,"13":180,"14":180,"15":185,"16":210,"17":270,"18":270,"19":270,"20":275,"21":275}');

-- Orly TO Disneyland
INSERT INTO rates (from_loc, to_loc, label, active, prices) VALUES
('ORLY','DISNEYLAND','Orly TO Disneyland',1,'{"3":85,"4":90,"5":90,"6":100,"7":105,"8":110,"9":180,"10":180,"11":185,"12":195,"13":200,"14":200,"15":210,"16":215,"17":275,"18":280,"19":290,"20":295,"21":300}');

-- Beauvais Airport TO Disneyland
INSERT INTO rates (from_loc, to_loc, label, active, prices) VALUES
('BEAUVAIS','DISNEYLAND','Beauvais Airport TO Disneyland',1,'{"3":160,"4":165,"5":175,"6":180,"7":185,"8":185,"9":330,"10":335,"11":355,"12":350,"13":355,"14":360,"15":365,"16":365,"17":490,"18":490,"19":535,"20":535,"21":535}');

-- CDG TO Paris
INSERT INTO rates (from_loc, to_loc, label, active, prices) VALUES
('CDG','PARIS','CDG TO Paris',1,'{"3":80,"4":90,"5":90,"6":95,"7":100,"8":105,"9":185,"10":185,"11":185,"12":190,"13":190,"14":195,"15":200,"16":210,"17":290,"18":295,"19":300,"20":300,"21":300}');

-- Beauvais TO Paris
INSERT INTO rates (from_loc, to_loc, label, active, prices) VALUES
('BEAUVAIS','PARIS','Beauvais TO Paris',1,'{"3":160,"4":165,"5":165,"6":170,"7":175,"8":180,"9":330,"10":335,"11":360,"12":360,"13":360,"14":365,"15":370,"16":375,"17":515,"18":545,"19":545,"20":545,"21":545}');

-- Disneyland TO Paris
INSERT INTO rates (from_loc, to_loc, label, active, prices) VALUES
('DISNEYLAND','PARIS','Disneyland TO Paris',1,'{"3":90,"4":90,"5":105,"6":105,"7":115,"8":120,"9":180,"10":185,"11":285,"12":215,"13":220,"14":225,"15":230,"16":295,"17":295,"18":295,"19":295,"20":295,"21":295}');

-- Orly TO Paris
INSERT INTO rates (from_loc, to_loc, label, active, prices) VALUES
('ORLY','PARIS','Orly TO Paris',1,'{"3":75,"4":75,"5":85,"6":90,"7":95,"8":100,"9":175,"10":175,"11":175,"12":180,"13":180,"14":185,"15":190,"16":200,"17":270,"18":270,"19":275,"20":280,"21":285}');
