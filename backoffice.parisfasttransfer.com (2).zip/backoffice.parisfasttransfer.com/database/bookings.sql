-- Import this file in phpMyAdmin to create the database and bookings table
-- (phpMyAdmin -> Import tab -> choose this file -> Go)

CREATE DATABASE IF NOT EXISTS parisfasttransfer CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE parisfasttransfer;

CREATE TABLE IF NOT EXISTS bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ref VARCHAR(20) NOT NULL,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  phone VARCHAR(50),
  pickup VARCHAR(255),
  pickupaddr VARCHAR(255),
  dropoff VARCHAR(255),
  dropoffaddr VARCHAR(255),
  trip VARCHAR(20) DEFAULT 'One Way',
  pax INT DEFAULT 1,
  babyseat VARCHAR(50),
  flight VARCHAR(50),
  date DATE NULL,
  time VARCHAR(20),
  return_pickupaddr VARCHAR(255),
  return_dropoff VARCHAR(255),
  return_date DATE NULL,
  return_time VARCHAR(20),
  price DECIMAL(10,2) DEFAULT 0,
  notes TEXT,
  status VARCHAR(20) NOT NULL DEFAULT 'New',
  emailSent TINYINT(1) DEFAULT 0,
  created DATETIME DEFAULT CURRENT_TIMESTAMP
);
