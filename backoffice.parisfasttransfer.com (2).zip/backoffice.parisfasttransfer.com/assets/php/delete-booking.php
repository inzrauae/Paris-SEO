<?php
session_start();
header('Content-Type: application/json');
if (empty($_SESSION['admin_authenticated'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}
require_once __DIR__ . '/db-config.php';

$input = json_decode(file_get_contents('php://input'), true);
$id = (int) ($input['id'] ?? 0);

if (!$id) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid id']);
    exit;
}

$stmt = $pdo->prepare("DELETE FROM bookings WHERE id = :id");
$stmt->execute([':id' => $id]);

echo json_encode(['success' => true]);
