<?php
session_start();
header('Content-Type: application/json');
if (empty($_SESSION['admin_authenticated'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}
require_once __DIR__ . '/db-config.php';

$input = json_decode(file_get_contents('php://input'), true);
$id = (int) ($input['id'] ?? 0);
$from = $input['from'] ?? '';
$to = $input['to'] ?? '';
$active = !empty($input['active']) ? 1 : 0;
$pax = $input['pax'] ?? [];

$locationLabels = [
    'CDG' => 'CDG', 'ORLY' => 'Orly', 'BEAUVAIS' => 'Beauvais Airport',
    'DISNEYLAND' => 'Disneyland', 'PARIS' => 'Paris',
];
$label = ($locationLabels[$from] ?? $from) . ' TO ' . ($locationLabels[$to] ?? $to);
$pricesJson = json_encode($pax);

try {
    if ($id) {
        $stmt = $pdo->prepare("UPDATE rates SET from_loc=:from, to_loc=:to, label=:label, active=:active, prices=:prices WHERE id=:id");
        $stmt->execute([':from' => $from, ':to' => $to, ':label' => $label, ':active' => $active, ':prices' => $pricesJson, ':id' => $id]);
        echo json_encode(['success' => true, 'id' => $id]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO rates (from_loc, to_loc, label, active, prices) VALUES (:from, :to, :label, :active, :prices)");
        $stmt->execute([':from' => $from, ':to' => $to, ':label' => $label, ':active' => $active, ':prices' => $pricesJson]);
        echo json_encode(['success' => true, 'id' => (int) $pdo->lastInsertId()]);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: '.$e->getMessage()]);
}
