<?php
session_start();
header('Content-Type: application/json');
if (empty($_SESSION['admin_authenticated'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}
require_once __DIR__ . '/db-config.php';

$stmt = $pdo->query("SELECT * FROM bookings ORDER BY created DESC");
$rows = $stmt->fetchAll();

$bookings = array_map(function ($r) {
    return [
        'id'        => (int) $r['id'],
        'ref'       => $r['ref'],
        'name'      => $r['name'],
        'email'     => $r['email'],
        'phone'     => $r['phone'],
        'pickup'    => $r['pickup'],
        'dropoff'   => $r['dropoff'],
        'trip'      => $r['trip'],
        'pax'       => (int) $r['pax'],
        'flight'    => $r['flight'],
        'date'      => $r['date'],
        'time'      => $r['time'],
        'price'     => (float) $r['price'],
        'status'    => $r['status'],
        'notes'     => $r['notes'],
        'created'   => str_replace(' ', 'T', $r['created']),
        'emailSent' => (bool) $r['emailSent'],
    ];
}, $rows);

echo json_encode($bookings);
