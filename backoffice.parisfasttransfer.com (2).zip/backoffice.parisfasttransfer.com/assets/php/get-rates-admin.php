<?php
session_start();
header('Content-Type: application/json');
if (empty($_SESSION['admin_authenticated'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}
require_once __DIR__ . '/db-config.php';

$stmt = $pdo->query("SELECT id, from_loc, to_loc, label, active, prices FROM rates ORDER BY id");
$rows = $stmt->fetchAll();

$rates = array_map(function ($r) {
    return [
        'id'     => (int) $r['id'],
        'from'   => $r['from_loc'],
        'to'     => $r['to_loc'],
        'label'  => $r['label'],
        'active' => (bool) $r['active'],
        'pax'    => json_decode($r['prices'], true),
    ];
}, $rows);

echo json_encode($rates);
