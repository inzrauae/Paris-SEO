<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../../PHPMailer/src/Exception.php';
require '../../PHPMailer/src/PHPMailer.php';
require '../../PHPMailer/src/SMTP.php';

function sendMail($toEmail, $toName, $subject, $body, $fromEmail = 'fastransfer@parisfasttransfer.com', $fromName = 'Paris Fast Transfer')
{
  $mail = new PHPMailer(true);

  try {
    // SMTP settings
    $mail->isSMTP();
    $mail->Host = 'mail.parisfasttransfer.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'fastransfer@parisfasttransfer.com';
    $mail->Password = 'wErF1?[ae#i-8p5C';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;
    $mail->SMTPOptions = array(
      'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
      )
    );

    // Email setup
    $mail->setFrom($fromEmail, $fromName);
    $mail->addAddress($toEmail, $toName);
    $mail->addReplyTo($fromEmail, $fromName);

    // Content
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body = $body;

    // Send
    $mail->send();
    return true;
  } catch (Exception $e) {
    error_log("PHPMailer Error: " . $mail->ErrorInfo);
    return false;
  }
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {


  $name = trim($_POST['name'] ?? '');
  $phone = trim($_POST['phone'] ?? '');
  $email = trim($_POST['email'] ?? '');
  $pickup = trim($_POST['pickup'] ?? '');
  $pickupaddr = trim($_POST['pickupaddr'] ?? '');
  $dropoff = trim($_POST['dropoff'] ?? '');
  $dropoffaddr = trim($_POST['dropoffaddr'] ?? '');
  $passengers = trim($_POST['passengers'] ?? '');
  $date = trim($_POST['date'] ?? '');
  $time = trim($_POST['time'] ?? '');
  $babyseat = trim($_POST['babyseat'] ?? '');
  $flight = trim($_POST['flight'] ?? '');
  $return_pickupaddr = trim($_POST['return_pickupaddr'] ?? '');
  $return_dropoff = trim($_POST['return_dropoff'] ?? '');
  $return_date = trim($_POST['return_date'] ?? '');
  $return_time = trim($_POST['return_time'] ?? '');
  $price = trim($_POST['price'] ?? '');
  $message = trim($_POST['message'] ?? '');
  $pickuptype = trim($_POST['pickuptype'] ?? '');

  // Basic validations
  $errors = [];
  if ($name === '') {
    $errors[] = 'Full Name is required.';
  }
  if ($phone === '') {
    $errors[] = 'Telephone Number is required.';
  }
  if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Valid Email is required.';
  }
  if ($pickup === '') {
    $errors[] = 'Pickup Location is required.';
  }
  if ($dropoff === '') {
    $errors[] = 'Dropoff Location is required.';
  }
  if ($date === '') {
    $errors[] = 'Date is required.';
  }
  if ($time === '') {
    $errors[] = 'Time is required.';
  }
  if ($passengers === '' || !is_numeric($passengers) || (int) $passengers <= 0) {
    $errors[] = 'Valid Number of Passengers is required.';
  }

  // Conditional validation for return fields
  if ($pickuptype === 'Return') {
    if ($return_pickupaddr === '') {
      $errors[] = 'Return Pickup Address is required.';
    }
    if ($return_dropoff === '') {
      $errors[] = 'Return Dropoff Location is required.';
    }
  }
  if ($pickuptype === 'Return') {
    if ($return_date === '') {
      $errors[] = 'Return Date is required for Return trips.';
    }
    if ($return_time === '') {
      $errors[] = 'Return Time is required for Return trips.';
    }
  }

  if ($pickuptype === '') {
    $errors[] = 'Pickup Type is required.';
  }
  if ($price === '') {
    $errors[] = 'Price is required.';
  }
  if ($pickupaddr === '') {
    $errors[] = 'Pickup Address is required.';
  }
  if ($dropoffaddr === '') {
    $errors[] = 'Dropoff Address is required.';
  }
  // Baby seat is optional — no validation required
  if ($flight === '') {
    $errors[] = 'Flight/ Train Number is required.';
  }

  // If errors, show them and stop
  if (!empty($errors)) {
    echo '<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Form Validation Errors</title>
  <style>
    body { font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 0; }
    .container { max-width: 600px; margin: 50px auto; background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);} 
    h1 { color: #dc3545; }
    ul { text-align: left; }
    a.btn { display: inline-block; padding: 10px 20px; background: #004080; color: #fff; text-decoration: none; border-radius: 5px; margin-top: 20px; }
    a.btn:hover { background: #0066cc; }
  </style>
</head>
<body>
  <div class="container">
    <h1>Please fix the following</h1>
    <ul>';
    foreach ($errors as $e) {
      echo '<li>' . htmlspecialchars($e) . '</li>';
    }
    echo '</ul>
    <a href="../../book-ride.php" class="btn">Back to Booking Form</a>
  </div>
</body>
</html>';
    exit;
  }

  if (empty($errors)) {

    // ---- Save booking to database (so it shows up in the admin dashboard) ----
    require_once __DIR__ . '/db-config.php';
    $bookingRef = 'PFT-' . random_int(1000, 9999);
    try {
      $stmt = $pdo->prepare("INSERT INTO bookings
        (ref, name, email, phone, pickup, pickupaddr, dropoff, dropoffaddr, trip, pax, babyseat, flight, date, time, return_pickupaddr, return_dropoff, return_date, return_time, price, notes, status)
        VALUES
        (:ref, :name, :email, :phone, :pickup, :pickupaddr, :dropoff, :dropoffaddr, :trip, :pax, :babyseat, :flight, :date, :time, :return_pickupaddr, :return_dropoff, :return_date, :return_time, :price, :notes, 'New')");
      $stmt->execute([
        ':ref' => $bookingRef,
        ':name' => $name,
        ':email' => $email,
        ':phone' => $phone,
        ':pickup' => $pickup,
        ':pickupaddr' => $pickupaddr,
        ':dropoff' => $dropoff,
        ':dropoffaddr' => $dropoffaddr,
        ':trip' => $pickuptype,
        ':pax' => (int) $passengers,
        ':babyseat' => $babyseat,
        ':flight' => $flight,
        ':date' => $date ? date('Y-m-d', strtotime($date)) : null,
        ':time' => $time,
        ':return_pickupaddr' => $return_pickupaddr,
        ':return_dropoff' => $return_dropoff,
        ':return_date' => $return_date ? date('Y-m-d', strtotime($return_date)) : null,
        ':return_time' => $return_time,
        ':price' => $price !== '' ? $price : 0,
        ':notes' => $message,
      ]);
    } catch (PDOException $e) {
      error_log('Booking DB insert failed: ' . $e->getMessage());
    }
    // ---------------------------------------------------------------------

    $derivedSubject = 'Booking Confirmation - Paris Fast Transfer';

    // Start Email Body
    $body = '
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Booking Confirmation</title>
  <style>
    body {
      font-family: Arial, Helvetica, sans-serif;
      background-color: #f6f9fc;
      color: #333;
      margin: 0;
      padding: 0;
    }
    .container {
      max-width: 620px;
      margin: 40px auto;
      background: #ffffff;
      border-radius: 10px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.08);
      overflow: hidden;
    }
    .header {
      background: #004080;
      color: #fff;
      text-align: center;
      padding: 25px 20px;
    }
    .header h2 {
      margin: 0;
      font-size: 22px;
      font-weight: 600;
    }
    .content {
      padding: 25px 30px;
      font-size: 15px;
      line-height: 1.6;
    }
    h3 {
      color: #004080;
      margin-bottom: 12px;
      font-size: 18px;
      border-bottom: 2px solid #e8f0fe;
      padding-bottom: 5px;
    }
    .info {
      background-color: #f2f7ff;
      padding: 15px 20px;
      border-radius: 8px;
      margin-bottom: 20px;
    }
    .info p {
      margin: 6px 0;
      font-size: 14px;
    }
    .label {
      font-weight: 600;
      color: #004080;
      display: inline-block;
      width: 180px;
    }
    .message {
      background: #f9fafc;
      padding: 15px;
      border-left: 4px solid #0078d4;
      border-radius: 6px;
      font-style: italic;
      color: #444;
      margin-top: 10px;
    }
    .footer {
      text-align: center;
      padding: 15px;
      background: #f4f4f4;
      font-size: 13px;
      color: #555;
      border-top: 1px solid #eaeaea;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h2>Booking Confirmed!</h2>
      <p>Thank you for choosing <strong>Paris Fast Transfer</strong></p>
    </div>
    
    <div class="content">
      <p>Dear ' . htmlspecialchars($name) . ',</p>
      <p>Your booking has been successfully received and confirmed. Below are your trip details:</p>

      <h3>Booking Summary</h3>
      <div class="info">
        <p><span class="label">Name:</span> ' . htmlspecialchars($name) . '</p>
        <p><span class="label">Phone:</span> ' . htmlspecialchars($phone) . '</p>
        <p><span class="label">Email:</span> ' . htmlspecialchars($email) . '</p>
        <p><span class="label">Pickup Type:</span> ' . htmlspecialchars($pickuptype) . '</p>
        <p><span class="label">Pickup Location:</span> ' . htmlspecialchars($pickup) . '</p>
        <p><span class="label">Pickup Address:</span> ' . htmlspecialchars($pickupaddr) . '</p>
        <p><span class="label">Dropoff Location:</span> ' . htmlspecialchars($dropoff) . '</p>
        <p><span class="label">Dropoff Address:</span> ' . htmlspecialchars($dropoffaddr) . '</p>';

    if ($pickuptype === 'Return' && ($return_pickupaddr !== '' || $return_dropoff !== '')) {
      $body .= '
        <p><span class="label">Return Pickup Address:</span> ' . htmlspecialchars($return_pickupaddr) . '</p>
        <p><span class="label">Return Dropoff:</span> ' . htmlspecialchars($return_dropoff) . '</p>';
    }
    if ($pickuptype === 'Return' && ($return_date !== '' || $return_time !== '')) {
      $body .= '
        <p><span class="label">Return Date:</span> ' . htmlspecialchars($return_date) . '</p>
        <p><span class="label">Return Time:</span> ' . htmlspecialchars($return_time) . '</p>';
    }

    $body .= '
        <p><span class="label">Passengers:</span> ' . htmlspecialchars($passengers) . '</p>
        <p><span class="label">Date:</span> ' . htmlspecialchars($date) . '</p>
        <p><span class="label">Time:</span> ' . htmlspecialchars($time) . '</p>
        <p><span class="label">Flight/Train Number:</span> ' . htmlspecialchars($flight) . '</p>
        <p><span class="label">Baby Seats:</span> ' . htmlspecialchars($babyseat) . '</p>
        <p><span class="label">Total Price:</span> <strong style="color:#0078d4;">' . htmlspecialchars($price) . '</strong></p>
      </div>';

    if (!empty($message)) {
      $body .= '
      <h3>Your Message</h3>
      <div class="message">' . nl2br(htmlspecialchars($message)) . '</div>';
    }

    $body .= '
      <p style="margin-top:20px; font-size:14px; color:#555;">
        Our team will contact you soon to reconfirm your booking details.  
        If you have any questions, please reply to this email or call us at <strong>+33 752 24 44 44</strong>.
      </p>
    </div>

    <div class="footer">
      &copy; ' . date("Y") . ' Paris Fast Transfer. All rights reserved.<br>
      <a href="http://localhost:8000" style="color:#004080; text-decoration:none;">parisfasttransfer.com</a> |
      <a href="mailto:fastransfer@parisfasttransfer.com" style="color:#004080; text-decoration:none;">Contact Us</a>
    </div>
  </div>
</body>
</html>';

    try {
      // Send to customer
      $Is_customer_mail_send = sendMail($email, $name, $derivedSubject, $body);

      // Admin email subject
      $admin_subject = 'New Booking Received - Paris Fast Transfer';

      // Start Admin email body
      $admin_body = '
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>New Booking Received</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      font-family: "Segoe UI", Arial, sans-serif;
      background-color: #f5f7fa;
      color: #333;
      margin: 0;
      padding: 0;
    }
    .container {
      max-width: 620px;
      margin: 30px auto;
      background: #ffffff;
      border-radius: 10px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.08);
      overflow: hidden;
    }
    .header {
      background: linear-gradient(135deg, #dc3545, #e63946);
      color: #fff;
      text-align: center;
      padding: 25px 20px;
    }
    .header h2 {
      margin: 0;
      font-size: 22px;
      font-weight: 600;
    }
    .content {
      padding: 25px 30px;
    }
    h3 {
      color: #dc3545;
      margin-bottom: 12px;
      font-size: 18px;
      border-bottom: 2px solid #ffe0e3;
      padding-bottom: 5px;
    }
    .info {
      background-color: #fff5f5;
      padding: 15px 20px;
      border-radius: 8px;
      margin-bottom: 20px;
    }
    .label {
      font-weight: 600;
      color: #dc3545;
      display: inline-block;
      width: 180px;
    }
    .message {
      background: #f9fafc;
      padding: 15px;
      border-left: 4px solid #dc3545;
      border-radius: 6px;
      font-style: italic;
      color: #444;
      margin-top: 10px;
    }
    .footer {
      text-align: center;
      padding: 15px;
      background: #f4f4f4;
      font-size: 12px;
      color: #777;
      border-top: 1px solid #eaeaea;
    }
    @media only screen and (max-width: 600px) {
      .label { width: 100%; display: block; margin-bottom: 3px; }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h2>New Booking Received</h2>
      <p>From: ' . htmlspecialchars($name) . '</p>
    </div>
    <div class="content">
      <h3>Customer Information</h3>
      <div class="info">
        <p><span class="label">Name:</span> ' . htmlspecialchars($name) . '</p>
        <p><span class="label">Phone:</span> ' . htmlspecialchars($phone) . '</p>
        <p><span class="label">Email:</span> ' . htmlspecialchars($email) . '</p>
      </div>
      <h3>Trip Details</h3>
      <div class="info">
        <p><span class="label">Pickup Type:</span> ' . htmlspecialchars($pickuptype) . '</p>
        <p><span class="label">Pickup Location:</span> ' . htmlspecialchars($pickup) . '</p>
        <p><span class="label">Pickup Address:</span> ' . htmlspecialchars($pickupaddr) . '</p>
        <p><span class="label">Dropoff Location:</span> ' . htmlspecialchars($dropoff) . '</p>
        <p><span class="label">Dropoff Address:</span> ' . htmlspecialchars($dropoffaddr) . '</p>';

      if ($pickuptype === 'Return' && ($return_pickupaddr !== '' || $return_dropoff !== '')) {
        $admin_body .= '
        <p><span class="label">Return Pickup Address:</span> ' . htmlspecialchars($return_pickupaddr) . '</p>
        <p><span class="label">Return Dropoff:</span> ' . htmlspecialchars($return_dropoff) . '</p>';
      }
      if ($pickuptype === 'Return' && ($return_date !== '' || $return_time !== '')) {
        $admin_body .= '
        <p><span class="label">Return Date:</span> ' . htmlspecialchars($return_date) . '</p>
        <p><span class="label">Return Time:</span> ' . htmlspecialchars($return_time) . '</p>';
      }

      $admin_body .= '
      
        <p><span class="label">Passengers:</span> ' . htmlspecialchars($passengers) . '</p>
        <p><span class="label">Date:</span> ' . htmlspecialchars($date) . '</p>
        <p><span class="label">Time:</span> ' . htmlspecialchars($time) . '</p>
        <p><span class="label">Flight/Train Number:</span> ' . htmlspecialchars($flight) . '</p>
        <p><span class="label">Baby Seats:</span> ' . htmlspecialchars($babyseat) . '</p>
        <p><span class="label">Total Price:</span> <strong>' . htmlspecialchars($price) . '</strong></p>
      </div>';

      if ($message !== '') {
        $admin_body .= '
      <h3>Customer Message</h3>
      <div class="message">' . nl2br(htmlspecialchars($message)) . '</div>';
      }

      $admin_body .= '
      <p style="margin-top:20px; font-size:14px; background:#fff3cd; padding:10px; border-radius:5px; border-left:4px solid #ffc107;">
        Action Required: Please contact the customer to confirm this booking.
      </p>
    </div>
    <div class="footer">
      &copy; ' . date("Y") . ' Paris Fast Transfer Booking System<br>
      This email was sent automatically.
    </div>
  </div>
</body>
</html>';


      // Send to admin
      $Is_Admin_mail_send = sendMail("fastransfer@parisfasttransfer.com", "Admin", "New Booking Received from " . $name, $admin_body);

      // If BOTH emails failed to send, show the failure page instead of pretending it worked
      if (!$Is_customer_mail_send && !$Is_Admin_mail_send) {
        error_log("Booking from $name ($email) received but BOTH emails failed to send.");
        echo '<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Booking Failed</title>
  <style>
    body { font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 0; }
    .container { max-width: 600px; margin: 50px auto; background: #fff; padding: 30px; border-radius: 8px; text-align: center; box-shadow: 0 4px 8px rgba(0,0,0,0.1);} 
    h1 { color: #dc3545; }
    p { font-size: 16px; line-height: 1.5; }
    a.btn { display: inline-block; padding: 10px 20px; background: #004080; color: #fff; text-decoration: none; border-radius: 5px; margin-top: 20px; }
    a.btn:hover { background: #0066cc; }
  </style>
</head>
<body>
  <div class="container">
    <h1>Oops! Something Went Wrong</h1>
    <p>There was a problem processing your booking. Please try again or contact us directly.</p>
    <p>Email: <a href="mailto:Parisfasttransfer@gmail.com">Parisfasttransfer@gmail.com</a></p>
    <p>Phone: <a href="tel:+33752244444">+33 752 24 44 44</a></p>
    <a href="../../book-ride.php" class="btn">Back to Booking Form</a>
    </div>
</body>
</html>';
        exit;
      }

      // Redirect with query string
      $query_string = http_build_query([
        'name' => $name,
        'phone' => $phone,
        'email' => $email,
        'pickup' => $pickup,
        'pickupaddr' => $pickupaddr,
        'dropoff' => $dropoff,
        'dropoffaddr' => $dropoffaddr,
        'passengers' => $passengers,
        'date' => $date,
        'time' => $time,
        'babyseats' => $babyseat,
        'flight' => $flight,
        'return_pickupaddr' => $return_pickupaddr,
        'return_dropoff' => $return_dropoff,
        'return_date' => $return_date,
        'return_time' => $return_time,

        'price' => $price,
        'message' => $message,
        'pickuptype' => $pickuptype
      ]);

      header("Location: https://parisfasttransfer.com/thankyou.html?$query_string");
      exit();

    } catch (Exception $e) {
      echo '<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Booking Failed</title>
  <style>
    body { font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 0; }
    .container { max-width: 600px; margin: 50px auto; background: #fff; padding: 30px; border-radius: 8px; text-align: center; box-shadow: 0 4px 8px rgba(0,0,0,0.1);} 
    h1 { color: #dc3545; }
    p { font-size: 16px; line-height: 1.5; }
    a.btn { display: inline-block; padding: 10px 20px; background: #004080; color: #fff; text-decoration: none; border-radius: 5px; margin-top: 20px; }
    a.btn:hover { background: #0066cc; }
  </style>
</head>
<body>
  <div class="container">
    <h1>Oops! Something Went Wrong</h1>
    <p>There was a problem processing your booking. Please try again or contact us directly.</p>
    <p>Email: <a href="mailto:Parisfasttransfer@gmail.com">Parisfasttransfer@gmail.com</a></p>
    <p>Phone: <a href="tel:+33752244444">+33 752 24 44 44</a></p>
    <a href="../../book-ride.php" class="btn">Back to Booking Form</a>
    </div>
</body>
</html>';
      exit;
    }
  }
}
?>