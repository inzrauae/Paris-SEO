<?php
// Database connection settings — UPDATE these with your live hosting cPanel DB credentials
$DB_HOST = 'localhost';
$DB_NAME = 'parisfasttransfe_pftdb';
$DB_USER = 'parisfasttransfe_pftdb';
$DB_PASS = 'BuilderSPft2k26#';

// Admin dashboard login PIN — CHANGE THIS to your own secret 4-6 digit PIN
define('ADMIN_PIN', '1209928');

try {
    $pdo = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4", $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    die(json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]));
}
