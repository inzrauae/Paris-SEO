<?php
session_start();
header('Content-Type: application/json');
if (empty($_SESSION['admin_authenticated'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}
require_once __DIR__ . '/db-config.php';

$input = json_decode(file_get_contents('php://input'), true);
$id = (int) ($input['id'] ?? 0);
$status = $input['status'] ?? '';

$allowed = ['New', 'Confirmed', 'Completed', 'Cancelled'];
if (!$id || !in_array($status, $allowed, true)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid id or status']);
    exit;
}

$stmt = $pdo->prepare("UPDATE bookings SET status = :status WHERE id = :id");
$stmt->execute([':status' => $status, ':id' => $id]);

echo json_encode(['success' => true]);
