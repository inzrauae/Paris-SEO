<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
require_once __DIR__ . '/db-config.php';

// Static location metadata (names/keywords rarely change, kept simple here)
$locations = [
    'CDG'        => ['label' => 'CDG', 'keywords' => ['cdg', 'charles de gaulle']],
    'ORLY'       => ['label' => 'Orly', 'keywords' => ['orly']],
    'BEAUVAIS'   => ['label' => 'Beauvais Airport', 'keywords' => ['beauvais']],
    'DISNEYLAND' => ['label' => 'Disneyland', 'keywords' => ['disney']],
    'PARIS'      => ['label' => 'Paris', 'keywords' => ['paris']],
];

$paxColumns = range(3, 21);

$stmt = $pdo->query("SELECT from_loc, to_loc, label, prices FROM rates WHERE active = 1");
$rows = $stmt->fetchAll();

$routes = array_map(function ($r) {
    return [
        'from'   => $r['from_loc'],
        'to'     => $r['to_loc'],
        'label'  => $r['label'],
        'prices' => json_decode($r['prices'], true),
    ];
}, $rows);

echo json_encode([
    'locations'  => $locations,
    'paxColumns' => $paxColumns,
    'routes'     => $routes,
]);
