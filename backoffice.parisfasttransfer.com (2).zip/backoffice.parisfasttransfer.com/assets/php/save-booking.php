<?php
session_start();
header('Content-Type: application/json');
if (empty($_SESSION['admin_authenticated'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}
require_once __DIR__ . '/db-config.php';

$input = json_decode(file_get_contents('php://input'), true);
$id = (int) ($input['id'] ?? 0);

$fields = [
    'name'   => $input['name']   ?? '',
    'email'  => $input['email']  ?? '',
    'phone'  => $input['phone']  ?? '',
    'pickup' => $input['pickup'] ?? '',
    'dropoff'=> $input['dropoff']?? '',
    'trip'   => $input['trip']   ?? 'One Way',
    'pax'    => (int) ($input['pax'] ?? 1),
    'flight' => $input['flight'] ?? '',
    'date'   => $input['date']   ?? null,
    'time'   => $input['time']   ?? '',
    'price'  => (float) ($input['price'] ?? 0),
    'status' => $input['status'] ?? 'New',
    'notes'  => $input['notes']  ?? '',
];

if ($id) {
    // Update existing booking
    $stmt = $pdo->prepare("UPDATE bookings SET name=:name, email=:email, phone=:phone, pickup=:pickup,
        dropoff=:dropoff, trip=:trip, pax=:pax, flight=:flight, date=:date, time=:time, price=:price,
        status=:status, notes=:notes WHERE id=:id");
    $fields['id'] = $id;
    $stmt->execute($fields);
    echo json_encode(['success' => true, 'id' => $id]);
} else {
    // Create new booking (added directly from the dashboard, not the public form)
    $ref = 'PFT-' . random_int(1000, 9999);
    $stmt = $pdo->prepare("INSERT INTO bookings
        (ref, name, email, phone, pickup, dropoff, trip, pax, flight, date, time, price, status, notes, emailSent)
        VALUES (:ref, :name, :email, :phone, :pickup, :dropoff, :trip, :pax, :flight, :date, :time, :price, :status, :notes, 0)");
    $fields['ref'] = $ref;
    $stmt->execute($fields);
    echo json_encode(['success' => true, 'id' => (int) $pdo->lastInsertId(), 'ref' => $ref]);
}
