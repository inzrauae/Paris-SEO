<?php
session_start();
require_once __DIR__ . '/assets/php/db-config.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pin = $_POST['pin'] ?? '';
    if (hash_equals(ADMIN_PIN, $pin)) {
        $_SESSION['admin_authenticated'] = true;
        header('Location: admin-dashboard.php');
        exit;
    } else {
        $error = 'Incorrect PIN. Please try again.';
        sleep(1); // slow down brute-force guessing
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Login - Paris Fast Transfer</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  *{box-sizing:border-box;}
  html,body{margin:0;padding:0;}
  body{
    font-family:'Inter',system-ui,Arial,sans-serif;background:#0F1830;
    display:flex;align-items:center;justify-content:center;
    min-height:100vh;min-height:100dvh;
    padding:20px;
  }
  .box{
    background:#fff;padding:40px;border-radius:12px;box-shadow:0 8px 30px rgba(0,0,0,.25);
    width:100%;max-width:320px;text-align:center;
  }
  .logo{max-width:220px;width:100%;height:auto;margin-bottom:28px;}
  input[type=password]{
    width:100%;padding:12px;font-size:16px;text-align:center;letter-spacing:6px;
    border:1px solid #ccc;border-radius:8px;box-sizing:border-box;margin-bottom:16px;
  }
  button{width:100%;padding:13px;background:#C6963A;color:#241A05;border:none;border-radius:8px;font-size:16px;font-weight:700;cursor:pointer;}
  button:hover{background:#B3822F;}
  .error{color:#c0392b;margin-bottom:16px;font-size:14px;}

  @media (max-width:380px){
    .box{padding:28px 22px;border-radius:10px;}
    .logo{max-width:170px;margin-bottom:22px;}
  }
</style>
</head>
<body>
  <div class="box">
    <img class="logo" src="assets/img/logo/logo-light.png" alt="Paris Fast Transfer">
    <?php if ($error): ?><div class="error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    <form method="POST">
      <input type="password" name="pin" inputmode="numeric" maxlength="10" autofocus placeholder="Enter PIN" required>
      <button type="submit">Login</button>
    </form>
  </div>
</body>
</html>