<?php
session_start();
if (empty($_SESSION['admin_authenticated'])) {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Paris Fast Transfer — Admin</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600;9..144,700&family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600&display=swap" rel="stylesheet">
<style>
:root{
  --navy-950:#0F1830;
  --navy-900:#16223D;
  --navy-800:#1E2C4C;
  --navy-700:#2A3E68;
  --gold-600:#B3822F;
  --gold-500:#C6963A;
  --gold-100:#F3E6C8;
  --cream-50:#FAF7F1;
  --white:#FFFFFF;
  --ink-900:#1B1F27;
  --ink-600:#4B5160;
  --ink-500:#6B7280;
  --ink-400:#9CA3AF;
  --line:#E8E2D5;
  --line-soft:#F0ECE2;
  --success:#2F7A4D; --success-bg:#E5F3E9;
  --warn:#B7791F; --warn-bg:#FBF0DA;
  --danger:#B5443A; --danger-bg:#FBEAE8;
  --info:#2C5E8A; --info-bg:#E6F0F8;
  --shadow-sm: 0 1px 2px rgba(15,24,48,0.06);
  --shadow-md: 0 6px 20px rgba(15,24,48,0.08);
  --shadow-lg: 0 20px 50px rgba(15,24,48,0.16);
}
*{box-sizing:border-box;}
html,body{margin:0;padding:0;}
body{
  font-family:'Inter',sans-serif;
  background:var(--cream-50);
  color:var(--ink-900);
  -webkit-font-smoothing:antialiased;
}
h1,h2,h3,.font-display{font-family:'Fraunces',serif;}
.mono{font-family:'IBM Plex Mono',monospace;}
a{color:inherit;text-decoration:none;}
button{font-family:inherit;cursor:pointer;}
::selection{background:var(--gold-100);}

/* ---------- Layout ---------- */
.app{display:flex;min-height:100vh;}

.sidebar{
  width:236px;flex-shrink:0;background:var(--navy-950);
  color:#EDEFF5;display:flex;flex-direction:column;
  position:fixed;top:0;left:0;bottom:0;z-index:40;
  transition:transform .25s ease;
}
.sidebar-brand{
  display:flex;align-items:center;gap:10px;
  padding:22px 20px 18px 20px;border-bottom:1px solid rgba(255,255,255,0.08);
}
.brand-mark{
  width:34px;height:34px;border-radius:50%;
  background:radial-gradient(circle at 35% 30%, var(--gold-500), var(--gold-600) 70%);
  display:flex;align-items:center;justify-content:center;flex-shrink:0;
  box-shadow: inset 0 0 0 3px rgba(255,255,255,0.12);
}
.brand-mark svg{width:17px;height:17px;}
.brand-word{font-family:'Fraunces',serif;font-size:16.5px;line-height:1.15;font-weight:600;color:#F5F1E6;}
.brand-word span{display:block;font-family:'Inter',sans-serif;font-size:9.5px;letter-spacing:.14em;text-transform:uppercase;color:var(--gold-500);font-weight:600;margin-top:2px;}
.brand-logo-img{height:30px;width:auto;object-fit:contain;filter:brightness(0) invert(1);}

.nav{padding:14px 12px;display:flex;flex-direction:column;gap:2px;flex:1;}
.nav-label{font-size:10.5px;letter-spacing:.12em;text-transform:uppercase;color:#6B7896;padding:14px 10px 6px;font-weight:600;}
.nav-item{
  display:flex;align-items:center;gap:11px;padding:10px 12px;border-radius:9px;
  color:#C3C9DC;font-size:14px;font-weight:500;border:none;background:transparent;width:100%;text-align:left;
}
.nav-item svg{width:17px;height:17px;flex-shrink:0;opacity:.85;}
.nav-item:hover{background:rgba(255,255,255,0.06);color:#fff;}
.nav-item.active{background:var(--navy-800);color:#fff;box-shadow:inset 3px 0 0 var(--gold-500);}
.nav-item .count{margin-left:auto;background:rgba(255,255,255,0.1);font-size:11px;padding:1px 7px;border-radius:20px;font-family:'IBM Plex Mono',monospace;}

.sidebar-foot{padding:16px;border-top:1px solid rgba(255,255,255,0.08);display:flex;align-items:center;gap:10px;}
.avatar{width:32px;height:32px;border-radius:50%;background:var(--navy-700);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;color:var(--gold-500);flex-shrink:0;}
.sidebar-foot .who{font-size:12.5px;line-height:1.3;}
.sidebar-foot .who b{display:block;color:#fff;font-size:13px;}
.sidebar-foot .who span{color:#8891A8;}

.main{flex:1;margin-left:236px;display:flex;flex-direction:column;min-width:0;}

.topbar{
  position:sticky;top:0;z-index:30;background:rgba(250,247,241,0.88);backdrop-filter:blur(8px);
  border-bottom:1px solid var(--line);
  display:flex;align-items:center;justify-content:space-between;
  padding:16px 28px;gap:16px;
}
.topbar-title h1{font-size:21px;margin:0;font-weight:600;letter-spacing:-.01em;}
.topbar-title p{margin:2px 0 0;font-size:12.5px;color:var(--ink-500);}
.topbar-actions{display:flex;align-items:center;gap:10px;}
.searchbox{
  display:flex;align-items:center;gap:8px;background:#fff;border:1px solid var(--line);
  border-radius:9px;padding:8px 12px;min-width:220px;position:relative;
}
.search-suggestions{
  display:none;position:absolute;left:0;right:0;top:100%;margin-top:8px;background:#fff;
  border:1px solid var(--line);border-radius:14px;box-shadow:0 16px 40px rgba(15,24,48,0.12);
  max-height:260px;overflow-y:auto;z-index:30;
}
.suggestion-item{
  width:100%;text-align:left;border:none;background:transparent;color:var(--ink-900);
  padding:12px 14px;cursor:pointer;font-size:13px;display:flex;flex-direction:column;gap:4px;
}
.suggestion-item:hover{background:var(--line-soft);}
.suggestion-item .hint{font-size:12px;color:var(--ink-500);}
.searchbox input{border:none;outline:none;font-size:13.5px;width:100%;background:transparent;color:var(--ink-900);}
.searchbox svg{width:15px;height:15px;color:var(--ink-400);flex-shrink:0;}
.icon-btn{width:36px;height:36px;border-radius:9px;background:#fff;border:1px solid var(--line);display:flex;align-items:center;justify-content:center;color:var(--ink-600);}
.icon-btn svg{width:16px;height:16px;}
.menu-toggle{display:none;}

.btn{
  display:inline-flex;align-items:center;gap:7px;padding:9px 15px;border-radius:9px;
  font-size:13.5px;font-weight:600;border:1px solid transparent;white-space:nowrap;
}
.btn svg{width:15px;height:15px;}
.btn-primary{background:var(--navy-950);color:#fff;}
.btn-primary:hover{background:var(--navy-800);}
.btn-gold{background:var(--gold-500);color:#241A05;}
.btn-gold:hover{background:var(--gold-600);}
.btn-ghost{background:#fff;color:var(--ink-700);border-color:var(--line);}
.btn-ghost:hover{border-color:var(--ink-400);}
.btn-danger-ghost{background:#fff;color:var(--danger);border-color:var(--line);}
.btn-danger-ghost:hover{background:var(--danger-bg);border-color:var(--danger);}
.btn-sm{padding:6px 10px;font-size:12.5px;border-radius:7px;}
.btn:disabled{opacity:.5;cursor:not-allowed;}

.content{padding:24px 28px 60px;}
.page{display:none;}
.page.active{display:block;animation:fadein .25s ease;}
@keyframes fadein{from{opacity:0;transform:translateY(4px);}to{opacity:1;transform:translateY(0);}}

/* ---------- Cards / stats ---------- */
.stat-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:22px;}
.stat-card{background:#fff;border:1px solid var(--line);border-radius:14px;padding:18px 20px;box-shadow:var(--shadow-sm);position:relative;overflow:hidden;}
.stat-card .top{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;}
.stat-card .ic{width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center;}
.stat-card .ic svg{width:16px;height:16px;}
.stat-card .label{font-size:12px;color:var(--ink-500);font-weight:600;text-transform:uppercase;letter-spacing:.04em;}
.stat-card .value{font-family:'Fraunces',serif;font-size:30px;font-weight:600;margin-top:2px;}
.stat-card .delta{font-size:11.5px;margin-top:6px;color:var(--ink-500);}
.stat-card .delta.up{color:var(--success);}

.panel{background:#fff;border:1px solid var(--line);border-radius:14px;box-shadow:var(--shadow-sm);}
.panel-head{padding:18px 20px;border-bottom:1px solid var(--line-soft);display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;}
.panel-head h3{margin:0;font-size:16px;font-weight:600;}
.panel-head p{margin:2px 0 0;font-size:12.5px;color:var(--ink-500);}
.two-col{display:grid;grid-template-columns:1.6fr 1fr;gap:16px;align-items:start;}

/* route visual */
.route{display:flex;align-items:center;gap:8px;min-width:0;}
.route .pt{font-size:12.5px;font-weight:600;color:var(--ink-900);white-space:nowrap;}
.route-line{flex:1;height:1px;background-image:linear-gradient(to right, var(--ink-400) 40%, transparent 0%);background-size:6px 1px;background-repeat:repeat-x;position:relative;min-width:24px;}
.route-line svg{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:13px;height:13px;color:var(--gold-600);background:#fff;}

/* status badges */
.badge{display:inline-flex;align-items:center;gap:5px;font-size:11.5px;font-weight:700;padding:4px 9px;border-radius:20px;letter-spacing:.02em;}
.badge .dot{width:6px;height:6px;border-radius:50%;}
.badge.new{background:var(--info-bg);color:var(--info);} .badge.new .dot{background:var(--info);}
.badge.confirmed{background:var(--gold-100);color:var(--gold-600);} .badge.confirmed .dot{background:var(--gold-600);}
.badge.completed{background:var(--success-bg);color:var(--success);} .badge.completed .dot{background:var(--success);}
.badge.cancelled{background:var(--danger-bg);color:var(--danger);} .badge.cancelled .dot{background:var(--danger);}
.badge.active{background:var(--success-bg);color:var(--success);} .badge.active .dot{background:var(--success);}
.badge.inactive{background:#EEF0F3;color:var(--ink-500);} .badge.inactive .dot{background:var(--ink-400);}

/* table */
.table-wrap{overflow-x:auto;}
table{width:100%;border-collapse:collapse;min-width:760px;}
thead th{
  text-align:left;font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:var(--ink-500);
  font-weight:600;padding:11px 20px;border-bottom:1px solid var(--line);background:#FCFAF6;white-space:nowrap;
}
tbody td{padding:13px 20px;border-bottom:1px solid var(--line-soft);font-size:13.5px;vertical-align:middle;}
tbody tr:hover{background:#FCFBF7;}
tbody tr:last-child td{border-bottom:none;}
.cell-main{font-weight:600;color:var(--ink-900);}
.cell-sub{font-size:12px;color:var(--ink-500);margin-top:1px;}
.ref{font-family:'IBM Plex Mono',monospace;font-size:12px;color:var(--ink-600);background:#F4F1EA;padding:2px 7px;border-radius:5px;}
.row-actions{display:flex;gap:6px;justify-content:flex-end;}
.iconbtn{width:29px;height:29px;border-radius:7px;border:1px solid var(--line);background:#fff;display:inline-flex;align-items:center;justify-content:center;color:var(--ink-500);}
@media (max-width: 760px) {
  .recent-bookings-table{width:100%;min-width:0;border:none;}
  .recent-bookings-table thead{display:none;}
  .recent-bookings-table tbody,
  .recent-bookings-table tr,
  .recent-bookings-table td{display:block;width:100%;}
  .recent-bookings-table tr{margin-bottom:14px;border:1px solid var(--line-soft);border-radius:14px;background:#fff;overflow:hidden;padding:12px;}
  .recent-bookings-table td{padding:10px 0;border:none;border-bottom:1px solid var(--line-soft);position:relative;}
  .recent-bookings-table td:last-child{border-bottom:none;}
  .recent-bookings-table td::before{content:attr(data-label);display:block;font-size:11px;font-weight:700;color:var(--ink-500);margin-bottom:6px;text-transform:uppercase;letter-spacing:.06em;}
  .recent-bookings-table td .ref{display:block;margin-bottom:4px;}
  .recent-bookings-table td .cell-main{margin-top:0;}
  .recent-bookings-table td > .route{margin-top:0;}
  .recent-bookings-table td:last-child{padding-bottom:0;}
  .table-wrap{overflow-x:hidden;}
}
.iconbtn:hover{border-color:var(--ink-400);color:var(--ink-900);}
.iconbtn svg{width:14px;height:14px;}
.status-select{
  font-family:'Inter',sans-serif;font-size:12px;font-weight:600;border-radius:20px;border:1px solid var(--line);
  padding:5px 24px 5px 10px;background:#fff;color:var(--ink-700);appearance:none;
  background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 24 24' fill='none' stroke='%236B7280' stroke-width='3'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E");
  background-repeat:no-repeat;background-position:right 8px center;
}

.filter-bar{display:flex;gap:8px;padding:14px 20px 0;flex-wrap:wrap;}
.chip{border:1px solid var(--line);background:#fff;color:var(--ink-600);font-size:12.5px;font-weight:600;padding:6px 13px;border-radius:20px;}
.chip.active{background:var(--navy-950);color:#fff;border-color:var(--navy-950);}

.empty{padding:60px 20px;text-align:center;color:var(--ink-500);}
.empty svg{width:34px;height:34px;color:var(--ink-400);margin-bottom:10px;}
.empty b{display:block;color:var(--ink-900);font-size:14.5px;margin-bottom:3px;}

/* rates */
.route-card{background:#fff;border:1px solid var(--line);border-radius:14px;padding:16px 18px;box-shadow:var(--shadow-sm);}
.route-card-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;}
.pax-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:6px;}
.pax-cell{background:#FBF9F4;border:1px solid var(--line-soft);border-radius:8px;padding:7px 4px;text-align:center;}
.pax-cell .p{font-size:9.5px;color:var(--ink-500);font-weight:600;text-transform:uppercase;}
.pax-cell .v{font-family:'IBM Plex Mono',monospace;font-size:13px;font-weight:600;margin-top:2px;}

/* modal */
.overlay{position:fixed;inset:0;background:rgba(15,20,35,0.5);backdrop-filter:blur(2px);display:none;align-items:center;justify-content:center;z-index:100;padding:20px;}
.overlay.open{display:flex;}
.modal{background:#fff;border-radius:16px;width:100%;max-width:560px;max-height:88vh;overflow-y:auto;box-shadow:var(--shadow-lg);animation:pop .18s ease;}
@keyframes pop{from{opacity:0;transform:scale(.97) translateY(6px);}to{opacity:1;transform:scale(1) translateY(0);}}
.modal-head{padding:20px 22px;border-bottom:1px solid var(--line-soft);display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;background:#fff;z-index:2;}
.modal-head h3{margin:0;font-size:17px;}
.modal-head p{margin:2px 0 0;font-size:12px;color:var(--ink-500);}
.modal-close{width:30px;height:30px;border-radius:8px;border:1px solid var(--line);background:#fff;display:flex;align-items:center;justify-content:center;color:var(--ink-500);flex-shrink:0;}
.modal-close svg{width:14px;height:14px;}
.modal-body{padding:20px 22px;}
.modal-foot{padding:16px 22px;border-top:1px solid var(--line-soft);display:flex;justify-content:flex-end;gap:10px;position:sticky;bottom:0;background:#fff;}

.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
.field{display:flex;flex-direction:column;gap:6px;}
.field.full{grid-column:1/-1;}
.field label{font-size:12px;font-weight:600;color:var(--ink-600);}
.field input,.field select,.field textarea{
  border:1px solid var(--line);border-radius:9px;padding:9px 11px;font-size:13.5px;font-family:'Inter',sans-serif;
  outline:none;background:#FCFBF8;color:var(--ink-900);
}
.field input:focus,.field select:focus,.field textarea:focus{border-color:var(--gold-500);background:#fff;box-shadow:0 0 0 3px var(--gold-100);}
.field textarea{resize:vertical;min-height:64px;}

.divider-label{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--ink-400);margin:18px 0 10px;}

/* email note */
.email-note{display:flex;gap:10px;background:var(--info-bg);border:1px solid #CFE2F1;border-radius:10px;padding:11px 13px;font-size:12.5px;color:#254A6B;align-items:flex-start;margin-top:14px;}
.email-note svg{width:16px;height:16px;flex-shrink:0;margin-top:1px;}

/* toast */
.toast-wrap{position:fixed;bottom:20px;right:20px;z-index:200;display:flex;flex-direction:column;gap:8px;}
.toast{background:var(--navy-950);color:#fff;padding:11px 16px;border-radius:10px;font-size:13px;display:flex;align-items:center;gap:9px;box-shadow:var(--shadow-lg);animation:slidein .2s ease;}
.toast svg{width:15px;height:15px;color:var(--gold-500);flex-shrink:0;}
@keyframes slidein{from{opacity:0;transform:translateX(20px);}to{opacity:1;transform:translateX(0);}}

.sidebar-scrim{display:none;}
.sidebar-close{display:none;}

/* =======================================================================
   RESPONSIVE — mobile-first breakpoints
   1180px  large tablets / small laptops : tighten grids, keep sidebar
   1024px  tablets & below               : sidebar becomes an off-canvas toggle drawer
   640px   phones                        : single column everything, full-width modals
   400px   small phones                  : extra compaction
   ======================================================================= */

@media (max-width: 1180px){
  .stat-grid{grid-template-columns:repeat(2,1fr);}
  .two-col{grid-template-columns:1fr;}
  .pax-grid{grid-template-columns:repeat(5,1fr);}
}

/* ---- Tablet & below: off-canvas sidebar + toggle button ---- */
@media (max-width: 1024px){
  .sidebar{
    transform:translateX(-100%);width:264px;position:fixed;top:0;bottom:0;
    box-shadow:var(--shadow-lg);
  }
  .sidebar.open{transform:translateX(0);}
  .main{margin-left:0;}
  .menu-toggle{display:flex;}
  .sidebar-close{
    display:flex;margin-left:auto;width:32px;height:32px;border-radius:8px;
    align-items:center;justify-content:center;background:rgba(255,255,255,0.06);
    border:1px solid rgba(255,255,255,0.1);color:#EDEFF5;flex-shrink:0;
  }
  .sidebar-close svg{width:15px;height:15px;}
  .sidebar-scrim{display:none;position:fixed;inset:0;background:rgba(10,14,28,.45);z-index:39;}
  .sidebar-scrim.open{display:block;}
  body.no-scroll{overflow:hidden;}
  .searchbox{min-width:0;flex:1;}
  .pax-grid{grid-template-columns:repeat(4,1fr);}
  .panel-head{flex-direction:column;align-items:stretch;}
  .panel-head button{width:100%;justify-content:center;margin-top:10px;}
}

/* ---- Phones ---- */
@media (max-width: 640px){
  .topbar{padding:12px 14px;gap:10px;flex-wrap:wrap;}
  .topbar-title{width:100%;}
  .topbar-title h1{font-size:18px;}
  .topbar-actions{width:100%;justify-content:space-between;gap:8px;}
  .searchbox{min-width:0;flex:1;padding:7px 10px;}
  .content{padding:14px 12px 50px;}

  .stat-grid{grid-template-columns:1fr 1fr;gap:10px;}
  .stat-card{padding:14px 14px;}
  .stat-card .value{font-size:20px;}
  .stat-card .label{font-size:10.5px;}

  .two-col{grid-template-columns:1fr;gap:12px;}

  .form-grid{grid-template-columns:1fr;}
  .pax-grid{grid-template-columns:repeat(3,1fr);}
  .route-card{padding:14px;}

  .table-wrap{overflow-x:auto;-webkit-overflow-scrolling:touch;}
  table{min-width:680px;}
  thead th, tbody td{padding:10px 12px;}
  .row-actions{flex-wrap:wrap;justify-content:flex-start;gap:8px;}

  .modal{max-width:100%;width:100%;height:100%;max-height:100%;margin:0;border-radius:0;}
  .overlay{padding:0;}
  .modal-body{padding:16px;}
  .modal-foot{padding:14px 16px;flex-wrap:wrap;}
  .modal-foot .btn{flex:1;justify-content:center;}
  .field input,.field select,.field textarea{font-size:16px;} /* prevents iOS zoom-on-focus */

  .filter-bar{padding:12px 14px 0;}
  .btn{padding:9px 13px;font-size:13px;}
}

/* ---- Small phones ---- */
@media (max-width: 400px){
  .stat-grid{grid-template-columns:1fr;}
  .pax-grid{grid-template-columns:repeat(2,1fr);}
  .sidebar{width:88vw;}
  .topbar-title h1{font-size:16.5px;}
  .brand-word{font-size:15px;}
}
</style>
</head>
<body>

<div class="app">
  <!-- SIDEBAR -->
  <aside class="sidebar" id="sidebar">
    <div class="sidebar-brand">
      <img class="brand-logo-img" src="https://www.parisfasttransfer.com/assets/img/logo/logo-light.png" alt="Paris Fast Transfer"
           onerror="this.style.display='none'; document.getElementById('brandFallback').style.display='flex';">
      <div id="brandFallback" style="display:none;align-items:center;gap:10px;">
        <div class="brand-mark"><svg viewBox="0 0 24 24" fill="none" stroke="#241A05" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 17h14M6 17V9.5A2.5 2.5 0 0 1 8.5 7h7A2.5 2.5 0 0 1 18 9.5V17M4 12h16l-1.5-5.5a2 2 0 0 0-1.9-1.5H7.4a2 2 0 0 0-1.9 1.5L4 12Z"/><circle cx="8" cy="17" r="1.6" fill="#241A05" stroke="none"/><circle cx="16" cy="17" r="1.6" fill="#241A05" stroke="none"/></svg></div>
        <div class="brand-word">Paris Fast<span>Transfer · Admin</span></div>
      </div>
      <button class="sidebar-close" onclick="toggleSidebar(false)" aria-label="Close menu">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
      </button>
    </div>
    <nav class="nav">
      <div class="nav-label">Overview</div>
      <button class="nav-item active" data-page="dashboard" onclick="navigate('dashboard')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/></svg>
        Dashboard
      </button>
      <div class="nav-label">Manage</div>
      <button class="nav-item" data-page="bookings" onclick="navigate('bookings')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>
        Bookings <span class="count" id="navBookingCount">0</span>
      </button>
      <button class="nav-item" data-page="rates" onclick="navigate('rates')">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
        Trip Rates <span class="count" id="navRateCount">0</span>
      </button>
    </nav>
    <div class="sidebar-foot">
      <div class="avatar">A</div>
      <div class="who"><b>Admin</b><span>Paris Fast Transfer</span></div>
      <a href="logout.php" style="margin-left:auto;color:#8891A8;font-size:12.5px;text-decoration:underline;">Logout</a>
    </div>
  </aside>
  <div class="sidebar-scrim" id="scrim" onclick="toggleSidebar(false)"></div>

  <!-- MAIN -->
  <div class="main">
    <div class="topbar">
      <div style="display:flex;align-items:center;gap:12px;">
        <button class="icon-btn menu-toggle" onclick="toggleSidebar(true)">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
        </button>
        <div class="topbar-title">
          <h1 id="pageTitle">Dashboard</h1>
          <p id="pageSubtitle">Live overview of bookings and performance</p>
        </div>
      </div>
      <div class="topbar-actions">
        <div class="searchbox" id="searchBoxWrap">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>
          <input id="searchInput" placeholder="Search bookings, routes, customers…" oninput="onSearch(this.value)" onkeydown="handleSearchKey(event)">
          <div class="search-suggestions" id="searchSuggestions"></div>
        </div>
        <button class="icon-btn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 1 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg></button>
      </div>
    </div>

    <div class="content">

      <!-- DASHBOARD PAGE -->
      <section class="page active" id="page-dashboard">
        <div class="stat-grid">
          <div class="stat-card">
            <div class="top"><span class="label">Total Bookings</span>
              <div class="ic" style="background:var(--info-bg);color:var(--info);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg></div>
            </div>
            <div class="value" id="statTotal">0</div>
            <div class="delta up">Across all statuses</div>
          </div>
          <div class="stat-card">
            <div class="top"><span class="label">New Requests</span>
              <div class="ic" style="background:var(--gold-100);color:var(--gold-600);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2 3 14h7l-1 8 10-12h-7l1-8Z"/></svg></div>
            </div>
            <div class="value" id="statNew">0</div>
            <div class="delta">Awaiting confirmation</div>
          </div>
          <div class="stat-card">
            <div class="top"><span class="label">Confirmed Trips</span>
              <div class="ic" style="background:var(--success-bg);color:var(--success);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg></div>
            </div>
            <div class="value" id="statConfirmed">0</div>
            <div class="delta">Ready to dispatch</div>
          </div>
          <div class="stat-card">
            <div class="top"><span class="label">Est. Revenue</span>
              <div class="ic" style="background:var(--navy-800);color:var(--gold-500);"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 1v22M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg></div>
            </div>
            <div class="value" id="statRevenue">€0</div>
            <div class="delta up">Confirmed + completed</div>
          </div>
        </div>

        <div class="two-col">
          <div class="panel">
            <div class="panel-head">
              <div><h3>Recent Bookings</h3><p>Latest requests submitted from the website form</p></div>
              <button class="btn btn-ghost btn-sm" onclick="navigate('bookings')">View all</button>
            </div>
            <div class="table-wrap">
              <table class="recent-bookings-table">
                <thead><tr><th>Reference</th><th>Customer</th><th>Route</th><th>Date</th><th>Status</th></tr></thead>
                <tbody id="recentBookingsBody"></tbody>
              </table>
            </div>
          </div>

          <div class="panel">
            <div class="panel-head"><div><h3>Status Breakdown</h3><p>Current pipeline</p></div></div>
            <div style="padding:20px;display:flex;flex-direction:column;gap:14px;" id="statusBreakdown"></div>
          </div>
        </div>
      </section>

      <!-- BOOKINGS PAGE -->
      <section class="page" id="page-bookings">
        <div class="panel">
          <div class="panel-head">
            <div><h3>All Bookings</h3><p>Every request submitted through the website booking form arrives here, and a confirmation email is sent automatically.</p></div>
            <button class="btn btn-gold" onclick="openBookingModal(null)">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>
              New Booking
            </button>
          </div>
          <div class="filter-bar" id="statusChips"></div>
          <div class="table-wrap">
            <table>
              <thead><tr>
                <th>Reference</th><th>Customer</th><th>Route</th><th>Trip</th><th>Date &amp; Time</th><th>Pax</th><th>Price</th><th>Status</th><th style="text-align:right;">Actions</th>
              </tr></thead>
              <tbody id="bookingsBody"></tbody>
            </table>
          </div>
          <div class="empty" id="bookingsEmpty" style="display:none;">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>
            <b>No bookings match this view</b>
            Try a different status filter or search term.
          </div>
        </div>
      </section>

      <!-- RATES PAGE -->
      <section class="page" id="page-rates">
        <div class="panel" style="margin-bottom:18px;">
          <div class="panel-head">
            <div><h3>Trip Rates</h3><p>Fixed prices shown on the public "Our Rates" page, by route and passenger count. Edit here to update the live site.</p></div>
            <button class="btn btn-gold" onclick="openRateModal(null)">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>
              New Route
            </button>
          </div>
        </div>
        <div id="ratesGrid" style="display:flex;flex-direction:column;gap:14px;"></div>
      </section>

    </div>
  </div>
</div>

<!-- BOOKING MODAL -->
<div class="overlay" id="bookingOverlay">
  <div class="modal">
    <div class="modal-head">
      <div><h3 id="bookingModalTitle">New Booking</h3><p>Fields match the website's booking form</p></div>
      <button class="modal-close" onclick="closeModal('bookingOverlay')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg></button>
    </div>
    <div class="modal-body">
      <form id="bookingForm" class="form-grid" onsubmit="return saveBooking(event)">
        <div class="field"><label>Customer name</label><input required id="f_name" placeholder="e.g. Marie Laurent"></div>
        <div class="field"><label>Email</label><input required type="email" id="f_email" placeholder="name@email.com"></div>
        <div class="field"><label>Phone</label><input id="f_phone" placeholder="+33 …"></div>
        <div class="field"><label>Passengers</label>
          <select id="f_pax"></select>
        </div>
        <div class="field"><label>Pick-up location</label>
          <select id="f_pickup">
            <option>Paris</option><option>Disneyland</option><option>Airport CDG</option><option>Airport Orly</option><option>Airport Beauvais</option>
          </select>
        </div>
        <div class="field"><label>Drop-off location</label>
          <select id="f_dropoff">
            <option>Disneyland</option><option>Paris</option><option>Airport CDG</option><option>Airport Orly</option><option>Airport Beauvais</option>
          </select>
        </div>
        <div class="field"><label>Trip type</label>
          <select id="f_trip"><option>One way</option><option>Return</option></select>
        </div>
        <div class="field"><label>Flight number (optional)</label><input id="f_flight" placeholder="e.g. AF1380"></div>
        <div class="field"><label>Date</label><input required type="date" id="f_date"></div>
        <div class="field"><label>Time</label><input required type="time" id="f_time"></div>
        <div class="field"><label>Price (€)</label><input required type="number" min="0" id="f_price" placeholder="e.g. 90"></div>
        <div class="field"><label>Status</label>
          <select id="f_status"><option>New</option><option>Confirmed</option><option>Completed</option><option>Cancelled</option></select>
        </div>
        <div class="field full"><label>Notes</label><textarea id="f_notes" placeholder="Extra luggage, child seat, meeting point…"></textarea></div>
      </form>
      <div class="email-note">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 6-10 7L2 6"/></svg>
        <div>Saving this booking simulates the same email confirmation the customer receives when they submit the website form. <span id="emailStateNote">A confirmation will be sent to the customer and to Parisfasttransfer@gmail.com.</span></div>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-ghost" onclick="closeModal('bookingOverlay')">Cancel</button>
      <button class="btn btn-primary" onclick="document.getElementById('bookingForm').requestSubmit()">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
        Save Booking
      </button>
    </div>
  </div>
</div>

<!-- BOOKING VIEW MODAL -->
<div class="overlay" id="viewOverlay">
  <div class="modal" id="viewModalBody"></div>
</div>

<!-- RATE MODAL -->
<div class="overlay" id="rateOverlay">
  <div class="modal">
    <div class="modal-head">
      <div><h3 id="rateModalTitle">New Route</h3><p>Set fixed pricing per passenger count</p></div>
      <button class="modal-close" onclick="closeModal('rateOverlay')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg></button>
    </div>
    <div class="modal-body">
      <form id="rateForm" onsubmit="return saveRate(event)">
        <div class="form-grid">
          <div class="field"><label>Pick-up</label>
            <select id="r_from"><option>Paris</option><option>Disneyland</option><option>Airport CDG</option><option>Airport Orly</option><option>Airport Beauvais</option></select>
          </div>
          <div class="field"><label>Drop-off</label>
            <select id="r_to"><option>Disneyland</option><option>Paris</option><option>Airport CDG</option><option>Airport Orly</option><option>Airport Beauvais</option></select>
          </div>
          <div class="field"><label>Status</label>
            <select id="r_active"><option value="1">Active</option><option value="0">Inactive</option></select>
          </div>
        </div>
        <div class="divider-label">Price by passenger count (€)</div>
        <div class="form-grid" id="rPaxFields"></div>
      </form>
    </div>
    <div class="modal-foot">
      <button class="btn btn-ghost" onclick="closeModal('rateOverlay')">Cancel</button>
      <button class="btn btn-primary" onclick="document.getElementById('rateForm').requestSubmit()">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
        Save Route
      </button>
    </div>
  </div>
</div>

<div class="toast-wrap" id="toastWrap"></div>

<script>
/* ---------------- ICONS ---------------- */
const ICON = {
  mail:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 6-10 7L2 6"/></svg>',
  eye:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8Z"/><circle cx="12" cy="12" r="3"/></svg>',
  edit:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>',
  trash:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0-1 14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2L4 6"/></svg>',
  plane:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M10.5 21 12 16l-6.5-4L4 13.5 2 13l3-4-3-1 1.5-1.5L8 8l4-6 2 1-2 6 6.5 4-1 2-6.5-2-1 5 2 1.5-1 1.5-2-1Z"/></svg>',
  car:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 17h14M6 17V9.5A2.5 2.5 0 0 1 8.5 7h7A2.5 2.5 0 0 1 18 9.5V17M4 12h16l-1.6-5.6A2 2 0 0 0 16.5 5h-9a2 2 0 0 0-1.9 1.4L4 12Z"/><circle cx="8" cy="17" r="1.6"/><circle cx="16" cy="17" r="1.6"/></svg>',
  check:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>',
  phone:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.3 1.9.6 2.7a2 2 0 0 1-.5 2.1L8 9.6a16 16 0 0 0 6.4 6.4l1.1-1.2a2 2 0 0 1 2.1-.5c.9.3 1.8.5 2.7.6a2 2 0 0 1 1.7 2Z"/></svg>',
  cal:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>',
  pin:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>',
  users:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/></svg>'
};

/* ---------------- DATA ---------------- */
const LOCS = ["Paris","Disneyland","Airport CDG","Airport Orly","Airport Beauvais"];
const shortLoc = l => l.replace('Airport ','');

let bookings = [];

const PAX_TIERS = [3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21];
let rates = []; // loaded live from the database via get-rates-admin.php

// The dashboard UI uses display labels ("Airport CDG"); the database/public site
// use canonical keys ("CDG") — these maps translate between the two.
const LOC_KEY_MAP = {"Airport CDG":"CDG","Airport Orly":"ORLY","Airport Beauvais":"BEAUVAIS","Disneyland":"DISNEYLAND","Paris":"PARIS"};
const LOC_KEY_REVERSE = {CDG:"Airport CDG",ORLY:"Airport Orly",BEAUVAIS:"Airport Beauvais",DISNEYLAND:"Disneyland",PARIS:"Paris"};

async function loadRates(){
  try{
    const res = await fetch('assets/php/get-rates-admin.php');
    if(!res.ok) throw new Error('HTTP '+res.status);
    const data = await res.json();
    rates = data.map(r => ({id:r.id, from:LOC_KEY_REVERSE[r.from]||r.from, to:LOC_KEY_REVERSE[r.to]||r.to, active:r.active, pax:r.pax}));
  }catch(err){
    console.error('Failed to load rates:', err);
    toast('Could not load rates — check the database connection');
    rates = [];
  }
  renderRates();
}

let state = {page:'dashboard', search:'', statusFilter:'all'};

function matchesSearch(b){
  if(!state.search) return true;
  const q = state.search;
  return [b.name,b.email,b.ref,b.pickup,b.dropoff,b.phone,b.trip,b.status].join(' ').toLowerCase().includes(q);
}

/* ---------------- LOAD FROM DATABASE ---------------- */
async function loadBookings(){
  try{
    const res = await fetch('assets/php/get-bookings.php');
    if(!res.ok) throw new Error('HTTP '+res.status);
    bookings = await res.json();
  }catch(err){
    console.error('Failed to load bookings:', err);
    toast('Could not load bookings — check XAMPP Apache/MySQL are running');
    bookings = [];
  }
  renderAll();
}

/* ---------------- NAV ---------------- */
function navigate(page){
  state.page = page;
  document.querySelectorAll('.nav-item').forEach(n=>n.classList.toggle('active', n.dataset.page===page));
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  document.getElementById('page-'+page).classList.add('active');
  const titles = {dashboard:['Dashboard','Live overview of bookings and performance'],
                  bookings:['Bookings','Every request from the website booking form'],
                  rates:['Trip Rates','Manage fixed pricing shown on the public site']};
  document.getElementById('pageTitle').textContent = titles[page][0];
  document.getElementById('pageSubtitle').textContent = titles[page][1];
  document.getElementById('searchBoxWrap').style.visibility = page==='rates' ? 'hidden' : 'visible';
  toggleSidebar(false);
  renderAll();
}
function toggleSidebar(open){
  document.getElementById('sidebar').classList.toggle('open', open);
  document.getElementById('scrim').classList.toggle('open', open);
  document.body.classList.toggle('no-scroll', open);
}
window.addEventListener('resize', ()=>{
  if(window.innerWidth > 1024) toggleSidebar(false);
});
document.addEventListener('keydown', e=>{
  if(e.key === 'Escape') toggleSidebar(false);
});
function onSearch(v){ state.search = v.toLowerCase().trim(); renderAll(); renderSearchSuggestions(); }

function renderSearchSuggestions(){
  const suggestEl = document.getElementById('searchSuggestions');
  const query = state.search;
  if(!query){ suggestEl.style.display='none'; suggestEl.innerHTML=''; return; }
  const matches = bookings.filter(matchesSearch).slice(0,5);
  if(!matches.length){ suggestEl.style.display='none'; suggestEl.innerHTML=''; return; }
  suggestEl.innerHTML = '';
  matches.forEach(b => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'suggestion-item';
    btn.innerHTML = `
      <span>${b.ref} · ${b.name}</span>
      <span class="hint">${shortLoc(b.pickup)} → ${shortLoc(b.dropoff)} · ${fmtDate(b.date)}</span>
    `;
    btn.addEventListener('click', () => applySearch(b.ref, `${b.ref} · ${b.name}`));
    suggestEl.appendChild(btn);
  });
  suggestEl.style.display='block';
}

function applySearch(searchTerm, displayText){
  const input = document.getElementById('searchInput');
  input.value = displayText;
  state.search = searchTerm.toLowerCase().trim();
  renderAll();
  const suggestEl = document.getElementById('searchSuggestions');
  suggestEl.style.display = 'none';
}

function handleSearchKey(e){
  if(e.key === 'Enter'){
    e.preventDefault();
    const value = e.target.value.trim();
    state.search = value.toLowerCase();
    renderAll();
    renderSearchSuggestions();
  }
}

/* ---------------- TOAST ---------------- */
function toast(msg){
  const wrap = document.getElementById('toastWrap');
  const el = document.createElement('div');
  el.className='toast';
  el.innerHTML = ICON.check + '<span>'+msg+'</span>';
  wrap.appendChild(el);
  setTimeout(()=>{ el.style.opacity='0'; el.style.transition='opacity .3s'; setTimeout(()=>el.remove(),300); }, 2600);
}

/* ---------------- RENDER: DASHBOARD ---------------- */
function renderDashboard(){
  const total = bookings.length;
  const news = bookings.filter(b=>b.status==='New').length;
  const conf = bookings.filter(b=>b.status==='Confirmed').length;
  const revenue = bookings.filter(b=>b.status==='Confirmed'||b.status==='Completed').reduce((s,b)=>s+Number(b.price||0),0);
  document.getElementById('statTotal').textContent = total;
  document.getElementById('statNew').textContent = news;
  document.getElementById('statConfirmed').textContent = conf;
  document.getElementById('statRevenue').textContent = '€'+revenue.toLocaleString();

  const recent = [...bookings].filter(matchesSearch).sort((a,b)=> new Date(b.created)-new Date(a.created)).slice(0,5);
  document.getElementById('recentBookingsBody').innerHTML = recent.map(b=>`
    <tr onclick="openView(${b.id})" style="cursor:pointer;">
      <td data-label="Reference"><span class="ref">${b.ref}</span></td>
      <td data-label="Customer"><div class="cell-main">${b.name}</div><div class="cell-sub">${b.email}</div></td>
      <td data-label="Route">${routeHtml(b.pickup,b.dropoff)}</td>
      <td data-label="Date" class="mono">${fmtDate(b.date)}</td>
      <td data-label="Status">${badge(b.status)}</td>
    </tr>`).join('') || `<tr><td colspan="5" style="text-align:center;color:var(--ink-500);padding:24px;">No bookings yet</td></tr>`;

  const statuses = ['New','Confirmed','Completed','Cancelled'];
  const colors = {New:'info',Confirmed:'gold-600',Completed:'success',Cancelled:'danger'};
  document.getElementById('statusBreakdown').innerHTML = statuses.map(s=>{
    const count = bookings.filter(b=>b.status===s).length;
    const pct = total? Math.round(count/total*100) : 0;
    return `<div>
      <div style="display:flex;justify-content:space-between;font-size:12.5px;margin-bottom:6px;">
        <span style="font-weight:600;">${s}</span><span class="mono" style="color:var(--ink-500);">${count} · ${pct}%</span>
      </div>
      <div style="height:7px;border-radius:6px;background:var(--line-soft);overflow:hidden;">
        <div style="height:100%;width:${pct}%;background:var(--${colors[s]==='gold-600'?'gold-500':colors[s]});border-radius:6px;"></div>
      </div>
    </div>`;
  }).join('');
}

function routeHtml(from,to){
  return `<div class="route"><span class="pt">${shortLoc(from)}</span><span class="route-line">${ICON.car}</span><span class="pt">${shortLoc(to)}</span></div>`;
}
function badge(status){
  const map = {New:'new',Confirmed:'confirmed',Completed:'completed',Cancelled:'cancelled'};
  return `<span class="badge ${map[status]}"><span class="dot"></span>${status}</span>`;
}
function fmtDate(d){
  const dt = new Date(d+'T00:00:00');
  return dt.toLocaleDateString('en-GB',{day:'2-digit',month:'short'});
}

/* ---------------- RENDER: BOOKINGS ---------------- */
function renderBookings(){
  document.getElementById('navBookingCount').textContent = bookings.length;
  const chips = ['all','New','Confirmed','Completed','Cancelled'];
  document.getElementById('statusChips').innerHTML = chips.map(c=>
    `<button class="chip ${state.statusFilter===c?'active':''}" onclick="setStatusFilter('${c}')">${c==='all'?'All':c} ${c==='all'?'':'('+bookings.filter(b=>b.status===c).length+')'}</button>`
  ).join('');

  let list = bookings.filter(b=> state.statusFilter==='all' || b.status===state.statusFilter);
  if(state.search){
    list = list.filter(matchesSearch);
  }
  list = [...list].sort((a,b)=> new Date(b.created)-new Date(a.created));

  document.getElementById('bookingsEmpty').style.display = list.length? 'none':'block';
  document.getElementById('bookingsBody').innerHTML = list.map(b=>`
    <tr>
      <td><span class="ref">${b.ref}</span></td>
      <td><div class="cell-main">${b.name}</div><div class="cell-sub">${b.email}</div></td>
      <td>${routeHtml(b.pickup,b.dropoff)}</td>
      <td>${b.trip}</td>
      <td class="mono">${fmtDate(b.date)} · ${b.time}</td>
      <td>${b.pax}</td>
      <td class="mono cell-main">€${b.price}</td>
      <td>
        <select class="status-select" onchange="updateStatus(${b.id}, this.value)">
          ${['New','Confirmed','Completed','Cancelled'].map(s=>`<option ${s===b.status?'selected':''}>${s}</option>`).join('')}
        </select>
      </td>
      <td>
        <div class="row-actions">
          <button class="iconbtn" title="View" onclick="openView(${b.id})">${ICON.eye}</button>
          <button class="iconbtn" title="Edit" onclick="openBookingModal(${b.id})">${ICON.edit}</button>
          <button class="iconbtn" title="Delete" onclick="deleteBooking(${b.id})">${ICON.trash}</button>
        </div>
      </td>
    </tr>`).join('');
}
function setStatusFilter(s){ state.statusFilter=s; renderBookings(); }
async function updateStatus(id, status){
  const b = bookings.find(x=>x.id===id); if(!b) return;
  try{
    const res = await fetch('assets/php/update-status.php', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({id, status})
    });
    if(!res.ok) throw new Error('HTTP '+res.status);
    b.status = status;
    renderAll();
    toast(`Booking ${b.ref} marked ${status} — customer notified by email`);
  }catch(err){
    console.error('Failed to update status:', err);
    toast('Could not update status — check the database connection');
  }
}
async function deleteBooking(id){
  const b = bookings.find(x=>x.id===id); if(!b) return;
  if(!confirm(`Delete booking ${b.ref} for ${b.name}? This cannot be undone.`)) return;
  try{
    const res = await fetch('assets/php/delete-booking.php', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({id})
    });
    if(!res.ok) throw new Error('HTTP '+res.status);
    bookings = bookings.filter(x=>x.id!==id);
    renderAll();
    toast(`Booking ${b.ref} deleted`);
  }catch(err){
    console.error('Failed to delete booking:', err);
    toast('Could not delete booking — check the database connection');
  }
}

/* ---------------- BOOKING MODAL ---------------- */
function fillPaxOptions(){
  const sel = document.getElementById('f_pax');
  sel.innerHTML = Array.from({length:24},(_,i)=>i+1).map(n=>`<option value="${n}">${n} passenger${n>1?'s':''}</option>`).join('');
}
let editingBookingId = null;
function openBookingModal(id){
  editingBookingId = id;
  fillPaxOptions();
  const title = document.getElementById('bookingModalTitle');
  if(id){
    const b = bookings.find(x=>x.id===id);
    title.textContent = `Edit Booking · ${b.ref}`;
    document.getElementById('emailStateNote').textContent = 'The customer will receive an updated confirmation email reflecting these changes.';
    f_name.value=b.name; f_email.value=b.email; f_phone.value=b.phone; f_pax.value=b.pax;
    f_pickup.value=b.pickup; f_dropoff.value=b.dropoff; f_trip.value=b.trip; f_flight.value=b.flight||'';
    f_date.value=b.date; f_time.value=b.time; f_price.value=b.price; f_status.value=b.status; f_notes.value=b.notes||'';
  } else {
    title.textContent = 'New Booking';
    document.getElementById('emailStateNote').textContent = 'A confirmation will be sent to the customer and to Parisfasttransfer@gmail.com.';
    document.getElementById('bookingForm').reset();
    f_pax.value = 2; f_status.value='New';
  }
  document.getElementById('bookingOverlay').classList.add('open');
}
async function saveBooking(e){
  e.preventDefault();
  const data = {
    id: editingBookingId || 0,
    name:f_name.value.trim(), email:f_email.value.trim(), phone:f_phone.value.trim(),
    pax:Number(f_pax.value), pickup:f_pickup.value, dropoff:f_dropoff.value, trip:f_trip.value,
    flight:f_flight.value.trim(), date:f_date.value, time:f_time.value, price:Number(f_price.value),
    status:f_status.value, notes:f_notes.value.trim()
  };
  try{
    const res = await fetch('assets/php/save-booking.php', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify(data)
    });
    if(!res.ok) throw new Error('HTTP '+res.status);
    const result = await res.json();
    if(editingBookingId){
      toast(`Booking updated — email resent to ${data.email}`);
    } else {
      toast(`Booking ${result.ref} created — confirmation emailed to ${data.email}`);
    }
    closeModal('bookingOverlay');
    await loadBookings();
  }catch(err){
    console.error('Failed to save booking:', err);
    toast('Could not save booking — check the database connection');
  }
  return false;
}

/* ---------------- VIEW MODAL ---------------- */
function openView(id){
  const b = bookings.find(x=>x.id===id); if(!b) return;
  document.getElementById('viewModalBody').innerHTML = `
    <div class="modal-head">
      <div><h3>${b.ref}</h3><p>Submitted ${new Date(b.created).toLocaleString('en-GB',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'})}</p></div>
      <button class="modal-close" onclick="closeModal('viewOverlay')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg></button>
    </div>
    <div class="modal-body">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
        ${badge(b.status)}
        <span class="mono" style="font-size:20px;font-weight:700;">€${b.price}</span>
      </div>
      <div style="background:#FBF9F4;border:1px solid var(--line-soft);border-radius:12px;padding:16px;margin-bottom:16px;">
        ${routeHtml(b.pickup,b.dropoff)}
        <div style="display:flex;gap:16px;margin-top:12px;font-size:12.5px;color:var(--ink-600);flex-wrap:wrap;">
          <span style="display:flex;align-items:center;gap:5px;">${ICON.cal}${fmtDate(b.date)} · ${b.time}</span>
          <span style="display:flex;align-items:center;gap:5px;">${ICON.users}${b.pax} passenger${b.pax>1?'s':''}</span>
          <span style="display:flex;align-items:center;gap:5px;">${ICON.plane}${b.trip}${b.flight?' · '+b.flight:''}</span>
        </div>
      </div>
      <div class="form-grid" style="margin-bottom:8px;">
        <div class="field"><label>Customer</label><div class="cell-main">${b.name}</div></div>
        <div class="field"><label>Email</label><div class="cell-main">${b.email}</div></div>
        <div class="field"><label>Phone</label><div class="cell-main">${b.phone||'—'}</div></div>
        <div class="field"><label>Status</label><div class="cell-main">${b.status}</div></div>
      </div>
      ${b.notes?`<div class="field full"><label>Notes</label><div style="font-size:13px;color:var(--ink-700);">${b.notes}</div></div>`:''}
      <div class="email-note">${ICON.mail}<div>Confirmation email ${b.emailSent?'was sent':'pending'} to <b>${b.email}</b> and a copy to Parisfasttransfer@gmail.com.</div></div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-ghost" onclick="resendEmail(${b.id})">${ICON.mail} Resend Email</button>
      <button class="btn btn-primary" onclick="closeModal('viewOverlay'); openBookingModal(${b.id})">${ICON.edit} Edit Booking</button>
    </div>
  `;
  document.getElementById('viewOverlay').classList.add('open');
}
function resendEmail(id){
  const b = bookings.find(x=>x.id===id);
  toast(`Confirmation email resent to ${b.email}`);
}

/* ---------------- RENDER: RATES ---------------- */
function renderRates(){
  document.getElementById('navRateCount').textContent = rates.length;
  document.getElementById('ratesGrid').innerHTML = rates.map(r=>`
    <div class="route-card">
      <div class="route-card-head">
        <div style="display:flex;align-items:center;gap:14px;">
          ${routeHtml(r.from, r.to)}
          ${badge(r.active?'Confirmed':'Cancelled').replace('confirmed','active').replace('cancelled','inactive').replace('Confirmed','Active').replace('Cancelled','Inactive')}
        </div>
        <div class="row-actions">
          <button class="iconbtn" title="Edit" onclick="openRateModal(${r.id})">${ICON.edit}</button>
          <button class="iconbtn" title="Delete" onclick="deleteRate(${r.id})">${ICON.trash}</button>
        </div>
      </div>
      <div class="pax-grid">
        ${PAX_TIERS.map(p=>`<div class="pax-cell"><div class="p">${p} pax</div><div class="v">€${r.pax[p]??'—'}</div></div>`).join('')}
      </div>
    </div>
  `).join('') || `<div class="empty">${ICON.car}<b>No routes yet</b>Add your first route to publish pricing.</div>`;
}

let editingRateId = null;
function fillPaxRateFields(existing){
  document.getElementById('rPaxFields').innerHTML = PAX_TIERS.map(p=>`
    <div class="field"><label>${p} passengers (€)</label><input type="number" min="0" id="rpax_${p}" value="${existing?existing[p]??'':''}" required></div>
  `).join('');
}
function openRateModal(id){
  editingRateId = id;
  document.getElementById('rateModalTitle').textContent = id? 'Edit Route' : 'New Route';
  if(id){
    const r = rates.find(x=>x.id===id);
    r_from.value=r.from; r_to.value=r.to; r_active.value = r.active?'1':'0';
    fillPaxRateFields(r.pax);
  } else {
    document.getElementById('rateForm').reset();
    fillPaxRateFields(null);
  }
  document.getElementById('rateOverlay').classList.add('open');
}
async function saveRate(e){
  e.preventDefault();
  const pax = {};
  PAX_TIERS.forEach(p=> pax[p] = Number(document.getElementById('rpax_'+p).value));
  const data = {
    id: editingRateId || 0,
    from: LOC_KEY_MAP[r_from.value] || r_from.value,
    to: LOC_KEY_MAP[r_to.value] || r_to.value,
    active: r_active.value==='1',
    pax
  };
  try{
    const res = await fetch('assets/php/save-rate.php', {
      method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(data)
    });
    if(!res.ok) throw new Error('HTTP '+res.status);
    toast(`Route "${shortLoc(r_from.value)} → ${shortLoc(r_to.value)}" ${editingRateId?'updated':'added'}`);
    closeModal('rateOverlay');
    await loadRates();
  }catch(err){
    console.error('Failed to save rate:', err);
    toast('Could not save route — check the database connection');
  }
  return false;
}
async function deleteRate(id){
  const r = rates.find(x=>x.id===id); if(!r) return;
  if(!confirm(`Remove the ${shortLoc(r.from)} → ${shortLoc(r.to)} route from the rates table?`)) return;
  try{
    const res = await fetch('assets/php/delete-rate.php', {
      method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({id})
    });
    if(!res.ok) throw new Error('HTTP '+res.status);
    rates = rates.filter(x=>x.id!==id);
    renderAll();
    toast('Route removed');
  }catch(err){
    console.error('Failed to delete rate:', err);
    toast('Could not delete route — check the database connection');
  }
}

/* ---------------- MODAL HELPERS ---------------- */
function closeModal(id){ document.getElementById(id).classList.remove('open'); }
document.querySelectorAll('.overlay').forEach(o=> o.addEventListener('click', e=>{ if(e.target===o) o.classList.remove('open'); }));

/* ---------------- INIT ---------------- */
function renderAll(){
  renderDashboard();
  renderBookings();
  renderRates();
}
loadBookings();
loadRates();
</script>
</body>
</html>
